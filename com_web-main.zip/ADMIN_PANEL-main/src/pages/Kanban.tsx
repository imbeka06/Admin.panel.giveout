export default function Kanban() {
  return (
    <div>Kanban</div>
  )
}
