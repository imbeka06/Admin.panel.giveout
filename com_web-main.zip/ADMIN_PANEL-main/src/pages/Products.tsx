import ProductListTable from "./Products/tables/ProductListTable";

export default function Products() {
  return (
    <ProductListTable />
  )
}
