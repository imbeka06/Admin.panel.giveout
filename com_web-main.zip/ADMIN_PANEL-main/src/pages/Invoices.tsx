import InvoiceListTable from "./Invoices/tables/InvoicesListTable";

export default function Invoices() {
  return (
    <InvoiceListTable />
  )
}
