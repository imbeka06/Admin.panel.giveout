import './App.css'
import Home from './pages/Home'

function App() {
  return (
    <div
      className='bg-inherit w-full h-full'
    >
      <Home />
    </div>
  )
}

export default App
